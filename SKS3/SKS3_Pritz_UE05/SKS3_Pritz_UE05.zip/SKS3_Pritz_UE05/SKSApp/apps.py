from django.apps import AppConfig


class SksappConfig(AppConfig):
    name = 'SKSApp'
