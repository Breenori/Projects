"""
Package for SKS3_Pritz_UE05.
"""
