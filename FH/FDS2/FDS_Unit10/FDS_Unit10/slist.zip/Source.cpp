#include "slist.h"


void main()
{
	slist_t list;
	for (int i(0); i < 20; i++)
	{
		list.push_back(i);
	}

	list.print_bigger_than(17);
}