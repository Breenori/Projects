#include<iostream>

void main()
{
	std::cout << "Hello world!\n";
}